﻿namespace $rootnamespace$
{
    public partial class $safeitemname$
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }    
    }
}
