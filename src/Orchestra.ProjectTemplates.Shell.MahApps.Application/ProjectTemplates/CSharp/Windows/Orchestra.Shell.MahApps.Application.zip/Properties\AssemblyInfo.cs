﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyProduct("$projectname$")]
[assembly: AssemblyDescription("$projectname$")]
[assembly: NeutralResourcesLanguage("en-US")]

// Recommended: move all attributes below to a shared solution-wide assembly info named SolutionAssemblyInfo.cs

[assembly: AssemblyCompany("$registeredorganization$")]
[assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]