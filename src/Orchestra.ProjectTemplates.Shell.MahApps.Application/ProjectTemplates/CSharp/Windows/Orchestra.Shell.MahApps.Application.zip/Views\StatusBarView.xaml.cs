﻿namespace $safeprojectname$.Views
{
    public partial class StatusBarView
    {
        public StatusBarView()
        {
            InitializeComponent();
        }
    }
}